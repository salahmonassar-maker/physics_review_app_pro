import 'package:flutter/material.dart';
import 'unit_page.dart';

class HomePage extends StatelessWidget {
  final List<Map<String,String>> units = [
    {'id':'u1','title':'كمية التحرك والمقذوفات'},
    {'id':'u2','title':'القوى والطاقة'},
    {'id':'u3','title':'الدارات الكهربائية والمغناطيسية'},
    {'id':'u4','title':'الموجات والضوء'},
    {'id':'u5','title':'الفيزياء النووية والتطبيقات'},
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text('مراجعة فيزياء — الصف الثالث الثانوي')),
        body: Padding(
          padding: const EdgeInsets.all(12),
          child: ListView(
            children: units.map((u) {
              return Card(
                child: ListTile(
                  title: Text(u['title']!),
                  trailing: Icon(Icons.arrow_forward_ios),
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => UnitPage(unitId: u['id']!, unitTitle: u['title']!))),
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }
}
