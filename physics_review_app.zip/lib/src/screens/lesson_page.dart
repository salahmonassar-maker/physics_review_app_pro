import 'package:flutter/material.dart';

class LessonPage extends StatelessWidget {
  final String lessonId;
  final String title;
  final String summary;

  LessonPage({required this.lessonId, required this.title, required this.summary});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text(title)),
        body: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            children: [
              Expanded(child: SingleChildScrollView(child: Text(summary))),
              ElevatedButton(
                child: Text("الأسئلة التفاعلية"),
                onPressed: (){
                  // questions page not fully implemented in this zip
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}
