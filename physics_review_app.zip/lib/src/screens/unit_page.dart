import 'package:flutter/material.dart';
import 'lesson_page.dart';

class UnitPage extends StatelessWidget {
  final String unitId;
  final String unitTitle;

  UnitPage({required this.unitId, required this.unitTitle});

  @override
  Widget build(BuildContext context) {
    final lessons = [
      {'id':'l_kamiyat_1','title':'كمية التحرك والزخم','summary':'ملخص الدرس...'},
    ];

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: Text(unitTitle)),
        body: ListView(
          children: lessons.map((l){
            return Card(
              child: ListTile(
                title: Text(l['title']!),
                onTap: ()=> Navigator.push(context, 
                  MaterialPageRoute(builder: (_)=> LessonPage(
                    lessonId: l['id']!,
                    title: l['title']!,
                    summary: l['summary']!,
                  ))),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}
