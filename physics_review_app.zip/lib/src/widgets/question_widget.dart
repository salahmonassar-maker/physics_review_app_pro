import 'package:flutter/material.dart';

class QuestionWidget extends StatefulWidget {
  final Map<String, dynamic> question;
  final void Function(bool correct, int score) onAnswered;

  QuestionWidget({required this.question, required this.onAnswered});

  @override
  _QuestionWidgetState createState() => _QuestionWidgetState();
}

class _QuestionWidgetState extends State<QuestionWidget> {
  dynamic selected;
  bool checked=false;

  @override
  Widget build(BuildContext context) {
    final q = widget.question;
    final type = q['type'];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(q['text'] ?? '', style: TextStyle(fontSize: 18)),
        SizedBox(height: 10),
      ],
    );
  }
}
